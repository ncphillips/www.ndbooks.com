Static builds using Webhook open source software
===============
Includes Bourbon, Neat, and Bitters, plus normalize-scss, and a minimal print stylesheet.


run these commands from the site directory after installation.
```
bower update

npm install --save-dev grunt-contrib-sass

cd sass && gem update bitters

add static/cms.css to pages/cms.html

```