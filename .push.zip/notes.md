All pages are templated in pages folder

books
 - book
 - series
 - 

 some books have more than one language, that's not accounted for in the drop down. these are edge cases, but how to handle?

AUTHOR

TODO: give books listing more/even space
TODO: make nice buy/info buttons for books
TODO: Make an "extras" section and link to them on this page (for reviews, articles, bios, etc)
TODO: Put in Real Events





collections

catalog is apart from books now



Content Type  Item Count
article 461
author  652
book  1217
books 6
catalog 1
collection  1
event 15
global  1
pages 9
review  1814
series  4
shopitem  1
themes  8

461+652+1217+1814 = 4,147





